
import java.util.concurrent.Semaphore;

public class TrafficController {
    private Semaphore bridge = new Semaphore(1);

    public TrafficController() {
    }

    public void enterLeft() {
        try {
            this.bridge.acquire();
        } catch (Exception var2) {
        }

    }

    public void enterRight() {
        try {
            this.bridge.acquire();
        } catch (Exception var2) {
        }

    }

    public void leaveLeft() {
        try {
            this.bridge.release();
        } catch (Exception var2) {
        }

    }

    public void leaveRight() {
        try {
            this.bridge.release();
        } catch (Exception var2) {
        }

    }
}
